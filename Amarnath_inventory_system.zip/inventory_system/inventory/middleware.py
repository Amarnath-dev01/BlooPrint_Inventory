from django.utils import timezone
import logging
from django.utils.deprecation import MiddlewareMixin
logger = logging.getLogger("trackAPI")


class LogMiddleware(MiddlewareMixin):

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        path = request.get_full_path()
        method = request.method
        payload = request.GET
        if method == 'POST':
            payload = request.body
        user = request.user
        user_name = user.email if user.is_authenticated else "Anonymous User"
        response = self.get_response(request)
        try:
            status_code = response.status_code
            response_content = response.content.decode('utf-8')
            if status_code !=200:
                index = response_content.rfind("Exception Type")
                error = response_content[index:index+150].strip()
                logger.info(" {} {} {} \n{} \n{} [error:{}]\n {} \n{}".format(method, user_name, path, payload, status_code, error, timezone.now(), "---------------------------------------------------------------"))
            else:
                logger.info(" {} {} {} \n{} \n{} {} \n{}".format(method, user_name, path, payload, status_code, timezone.now(), "---------------------------------------------------------------"))
        except Exception as e:
            logger.info(" {} {} {} \n{} \n{} {} \n{}".format(
                    method, user_name, path, payload, status_code, timezone.now(), 
                    "---------------------------------------------------------------"
                ))

        return response