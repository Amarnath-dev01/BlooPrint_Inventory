from django.contrib.auth.models import User
from django.urls import reverse
from rest_framework.test import APITestCase, APIClient
from rest_framework import status
from .models import Item  # Assuming Item is in the same app as the test

class ItemTests(APITestCase):
    def setUp(self):
        self.user = User.objects.create_user(username="testuser", password="testpass123")
        self.client = APIClient()
        self.client.force_authenticate(user=self.user)

        self.item = Item.objects.create(
            name="Test Item",
            description="Test Description",
            price=100.0,
            stock_quantity=10,
            is_deleted=False
        )

    def test_create_item(self):
        url = reverse('create-item')  # Fixed URL
        data = {
            "name": "New Test Item",
            "description": "New Test Description",
            "price": 150.0,
            "stock_quantity": 20
        }
        response = self.client.post(url, data, format='json')
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)

    def test_get_item(self):
        url = reverse('item-detail-update-delete', kwargs={'item_id': self.item.id})  # Fixed URL
        response = self.client.get(url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['name'], self.item.name)

    def test_update_item(self):
        url = reverse('item-detail-update-delete', kwargs={'item_id': self.item.id})  # Fixed URL
        data = {
            "price": 120.0
        }
        response = self.client.put(url, data, format='json')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.item.refresh_from_db()
        self.assertEqual(self.item.price, 120.0)

    def test_delete_item(self):
        url = reverse('item-detail-update-delete', kwargs={'item_id': self.item.id})  # Fixed URL
        response = self.client.delete(url)
        self.assertEqual(response.status_code, status.HTTP_204_NO_CONTENT)
        self.item.refresh_from_db()
        self.assertTrue(self.item.is_deleted)

