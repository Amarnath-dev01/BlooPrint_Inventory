from rest_framework import status
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework_simplejwt.tokens import RefreshToken
from django.core.cache import cache
from django.contrib.auth.models import User
from rest_framework.decorators import api_view
from rest_framework.permissions import AllowAny
from django.contrib.auth import authenticate

from .models import Item
from .serializers import ItemSerializer
from django.shortcuts import get_object_or_404, render



class ItemDetailUpdateDeleteView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, item_id):
        cache_key = f'item_{item_id}'
        cached_item = cache.get(cache_key)
        
        if cached_item:
            # this is flag to indicate that redis is working
            cached_item["is_redis_cache"] = True
            return Response(cached_item, status=status.HTTP_200_OK)

        item = get_object_or_404(Item, id=item_id, is_deleted=False)
        serializer = ItemSerializer(item)
        
        # Cache the serialized data instead of the Response object
        cache.set(cache_key, serializer.data, timeout=300)  # Cache for 5 minutes

        return Response(serializer.data, status=status.HTTP_200_OK)

    def post(self, request):
        # Check if item with the same name already exists
        if Item.objects.filter(name=request.data.get('name')).exists():
            return Response({"error": "Item already exists."}, status=status.HTTP_400_BAD_REQUEST)
        
        # Deserialize the data
        serializer = ItemSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request, item_id):
        # Update item (PUT)
        item = get_object_or_404(Item, id=item_id, is_deleted=False)
        serializer = ItemSerializer(item, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, item_id):
        # Soft delete item (DELETE)
        item = get_object_or_404(Item, id=item_id, is_deleted=False)
        item.is_deleted = True
        item.save()
        return Response({"message": "Item deleted successfully."}, status=status.HTTP_204_NO_CONTENT)


@api_view(['POST'])
@permission_classes([AllowAny])
def register_user(request):
    username = request.data.get('username')
    password = request.data.get('password')
    
    if User.objects.filter(username=username).exists():
        return Response({"error": "User already exists"}, status=status.HTTP_400_BAD_REQUEST)

    user = User.objects.create_user(username=username, password=password)
    return Response({"message": "User created successfully"}, status=status.HTTP_201_CREATED)



# Helper function for JWT token generation
def get_tokens_for_user(user):
    refresh = RefreshToken.for_user(user)
    return {
        'refresh': str(refresh),
        'access': str(refresh.access_token),
    }

# Login and JWT token retrieval
@api_view(['POST'])
@permission_classes([AllowAny])
def login_user(request):
    username = request.data.get('username')
    password = request.data.get('password')
    user = authenticate(request, username=username, password=password)

    if user is not None:
        tokens = get_tokens_for_user(user)
        return Response(tokens)
    return Response({"error": "Invalid credentials"}, status=status.HTTP_400_BAD_REQUEST)
