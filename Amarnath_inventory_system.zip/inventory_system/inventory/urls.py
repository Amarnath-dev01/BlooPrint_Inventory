
from django.urls import path
from .views import ItemDetailUpdateDeleteView, register_user, login_user


urlpatterns = [
    path('register/', register_user, name="register"),
    path('login/', login_user, name="login"),
    path('items/', ItemDetailUpdateDeleteView.as_view(), name='create-item'),  # POST /items/
    path('items/<int:item_id>/', ItemDetailUpdateDeleteView.as_view(), name='item-detail-update-delete'),  # GET, PUT, DELETE /items/{item_id}/
]